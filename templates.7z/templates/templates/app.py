from flask import Flask, render_template, request
from flask import Flask, request, render_template, redirect, url_for
import requests
import os
import time

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 МБ

API_KEY = 'f8bcb602ebca5dab53b89602ef80782f679e0390f52c942eb5374ea520d6681b'

def scan_file_vt(file_path):
    # Шаг 1: Загружаем файл и получаем ID анализа
    url = 'https://www.virustotal.com/api/v3/files'
    headers = {'x-apikey': API_KEY}
    
    with open(file_path, 'rb') as f:
        files = {'file': (os.path.basename(file_path), f)}
        response = requests.post(url, files=files, headers=headers)
    
    if response.status_code != 200:
        return {'error': f'Ошибка загрузки файла: {response.status_code}'}
    
    analysis_id = response.json()['data']['id']
    
    
    # Шаг 2: Получаем результаты анализа
    analysis_url = f'https://www.virustotal.com/api/v3/analyses/{analysis_id}'
    
    # Ждем некоторое время, пока анализ завершится
    time.sleep(15)
    
    response = requests.get(analysis_url, headers=headers)
    
    if response.status_code == 200:
        return response.json()
    else:
        return {'error': f'Ошибка получения результатов: {response.status_code}'}
    
     

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('upload.html', error='Файл не выбран')
        file = request.files['file']
        if file.filename == '':
            return render_template('upload.html', error='Файл не выбран')
        
        os.makedirs('uploads', exist_ok=True)
        filepath = os.path.join('uploads', file.filename)
        file.save(filepath)
        
        try:
            result = scan_file_vt(filepath)
            if 'analysis_id' in result:
                return redirect(url_for('check_results', analysis_id=result['analysis_id']))
            return render_template('result.html', result=result)
        finally:
            os.remove(filepath)

        
    
    return render_template('upload.html')
# В файл app.py добавьте этот маршрут
@app.route('/results/<analysis_id>')
def check_results(analysis_id):
    analysis_url = f'https://www.virustotal.com/api/v3/analyses/{analysis_id}'
    response = requests.get(analysis_url, headers={'x-apikey': API_KEY})
    
    if response.status_code == 200:
        result = response.json()
        if result['data']['attributes']['status'] == 'completed':
            return render_template('result.html', result=result)
    
    # Если анализ не завершен, обновляем через 20 секунд
    return render_template('refresh.html', analysis_id=analysis_id)
if __name__ == '__main__':
    app.run(debug=True)